package androidx.autofill;

public final class R {
    public static final class attr {
        public static final int alpha = 0x7F010000;  // attr:alpha
        public static final int font = 0x7F010004;  // attr:font
        public static final int fontProviderAuthority = 0x7F010005;  // attr:fontProviderAuthority
        public static final int fontProviderCerts = 0x7F010006;  // attr:fontProviderCerts
        public static final int fontProviderFetchStrategy = 0x7F010007;  // attr:fontProviderFetchStrategy
        public static final int fontProviderFetchTimeout = 0x7F010008;  // attr:fontProviderFetchTimeout
        public static final int fontProviderPackage = 0x7F010009;  // attr:fontProviderPackage
        public static final int fontProviderQuery = 0x7F01000A;  // attr:fontProviderQuery
        public static final int fontStyle = 0x7F01000C;  // attr:fontStyle
        public static final int fontVariationSettings = 0x7F01000D;  // attr:fontVariationSettings
        public static final int fontWeight = 0x7F01000E;  // attr:fontWeight
        public static final int ttcIndex = 0x7F010012;  // attr:ttcIndex

    }

    public static final class color {
        public static final int notification_action_color_filter = 0x7F030012;  // color:notification_action_color_filter
        public static final int notification_icon_bg_color = 0x7F030013;  // color:notification_icon_bg_color

    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 0x7F040000;  // dimen:compat_button_inset_horizontal_material
        public static final int compat_button_inset_vertical_material = 0x7F040001;  // dimen:compat_button_inset_vertical_material
        public static final int compat_button_padding_horizontal_material = 0x7F040002;  // dimen:compat_button_padding_horizontal_material
        public static final int compat_button_padding_vertical_material = 0x7F040003;  // dimen:compat_button_padding_vertical_material
        public static final int compat_control_corner_material = 0x7F040004;  // dimen:compat_control_corner_material
        public static final int compat_notification_large_icon_max_height = 0x7F040005;  // dimen:compat_notification_large_icon_max_height
        public static final int compat_notification_large_icon_max_width = 0x7F040006;  // dimen:compat_notification_large_icon_max_width
        public static final int notification_action_icon_size = 0x7F040007;  // dimen:notification_action_icon_size
        public static final int notification_action_text_size = 0x7F040008;  // dimen:notification_action_text_size
        public static final int notification_big_circle_margin = 0x7F040009;  // dimen:notification_big_circle_margin
        public static final int notification_content_margin_start = 0x7F04000A;  // dimen:notification_content_margin_start
        public static final int notification_large_icon_height = 0x7F04000B;  // dimen:notification_large_icon_height
        public static final int notification_large_icon_width = 0x7F04000C;  // dimen:notification_large_icon_width
        public static final int notification_main_column_padding_top = 0x7F04000D;  // dimen:notification_main_column_padding_top
        public static final int notification_media_narrow_margin = 0x7F04000E;  // dimen:notification_media_narrow_margin
        public static final int notification_right_icon_size = 0x7F04000F;  // dimen:notification_right_icon_size
        public static final int notification_right_side_padding_top = 0x7F040010;  // dimen:notification_right_side_padding_top
        public static final int notification_small_icon_background_padding = 0x7F040011;  // dimen:notification_small_icon_background_padding
        public static final int notification_small_icon_size_as_large = 0x7F040012;  // dimen:notification_small_icon_size_as_large
        public static final int notification_subtext_size = 0x7F040013;  // dimen:notification_subtext_size
        public static final int notification_top_pad = 0x7F040014;  // dimen:notification_top_pad
        public static final int notification_top_pad_large_text = 0x7F040015;  // dimen:notification_top_pad_large_text

    }

    public static final class drawable {
        public static final int notification_action_background = 0x7F05001D;  // drawable:notification_action_background
        public static final int notification_bg = 0x7F05001E;  // drawable:notification_bg
        public static final int notification_bg_low = 0x7F05001F;  // drawable:notification_bg_low
        public static final int notification_bg_low_normal = 0x7F050020;  // drawable:notification_bg_low_normal
        public static final int notification_bg_low_pressed = 0x7F050021;  // drawable:notification_bg_low_pressed
        public static final int notification_bg_normal = 0x7F050022;  // drawable:notification_bg_normal
        public static final int notification_bg_normal_pressed = 0x7F050023;  // drawable:notification_bg_normal_pressed
        public static final int notification_icon_background = 0x7F050024;  // drawable:notification_icon_background
        public static final int notification_template_icon_bg = 0x7F050025;  // drawable:notification_template_icon_bg
        public static final int notification_template_icon_low_bg = 0x7F050026;  // drawable:notification_template_icon_low_bg
        public static final int notification_tile_bg = 0x7F050027;  // drawable:notification_tile_bg
        public static final int notify_panel_notification_icon_bg = 0x7F050028;  // drawable:notify_panel_notification_icon_bg

    }

    public static final class id {
        public static final int accessibility_action_clickable_span = 0x7F060000;  // id:accessibility_action_clickable_span
        public static final int accessibility_custom_action_0 = 0x7F060001;  // id:accessibility_custom_action_0
        public static final int accessibility_custom_action_1 = 0x7F060002;  // id:accessibility_custom_action_1
        public static final int accessibility_custom_action_10 = 0x7F060003;  // id:accessibility_custom_action_10
        public static final int accessibility_custom_action_11 = 0x7F060004;  // id:accessibility_custom_action_11
        public static final int accessibility_custom_action_12 = 0x7F060005;  // id:accessibility_custom_action_12
        public static final int accessibility_custom_action_13 = 0x7F060006;  // id:accessibility_custom_action_13
        public static final int accessibility_custom_action_14 = 0x7F060007;  // id:accessibility_custom_action_14
        public static final int accessibility_custom_action_15 = 0x7F060008;  // id:accessibility_custom_action_15
        public static final int accessibility_custom_action_16 = 0x7F060009;  // id:accessibility_custom_action_16
        public static final int accessibility_custom_action_17 = 0x7F06000A;  // id:accessibility_custom_action_17
        public static final int accessibility_custom_action_18 = 0x7F06000B;  // id:accessibility_custom_action_18
        public static final int accessibility_custom_action_19 = 0x7F06000C;  // id:accessibility_custom_action_19
        public static final int accessibility_custom_action_2 = 0x7F06000D;  // id:accessibility_custom_action_2
        public static final int accessibility_custom_action_20 = 0x7F06000E;  // id:accessibility_custom_action_20
        public static final int accessibility_custom_action_21 = 0x7F06000F;  // id:accessibility_custom_action_21
        public static final int accessibility_custom_action_22 = 0x7F060010;  // id:accessibility_custom_action_22
        public static final int accessibility_custom_action_23 = 0x7F060011;  // id:accessibility_custom_action_23
        public static final int accessibility_custom_action_24 = 0x7F060012;  // id:accessibility_custom_action_24
        public static final int accessibility_custom_action_25 = 0x7F060013;  // id:accessibility_custom_action_25
        public static final int accessibility_custom_action_26 = 0x7F060014;  // id:accessibility_custom_action_26
        public static final int accessibility_custom_action_27 = 0x7F060015;  // id:accessibility_custom_action_27
        public static final int accessibility_custom_action_28 = 0x7F060016;  // id:accessibility_custom_action_28
        public static final int accessibility_custom_action_29 = 0x7F060017;  // id:accessibility_custom_action_29
        public static final int accessibility_custom_action_3 = 0x7F060018;  // id:accessibility_custom_action_3
        public static final int accessibility_custom_action_30 = 0x7F060019;  // id:accessibility_custom_action_30
        public static final int accessibility_custom_action_31 = 0x7F06001A;  // id:accessibility_custom_action_31
        public static final int accessibility_custom_action_4 = 0x7F06001B;  // id:accessibility_custom_action_4
        public static final int accessibility_custom_action_5 = 0x7F06001C;  // id:accessibility_custom_action_5
        public static final int accessibility_custom_action_6 = 0x7F06001D;  // id:accessibility_custom_action_6
        public static final int accessibility_custom_action_7 = 0x7F06001E;  // id:accessibility_custom_action_7
        public static final int accessibility_custom_action_8 = 0x7F06001F;  // id:accessibility_custom_action_8
        public static final int accessibility_custom_action_9 = 0x7F060020;  // id:accessibility_custom_action_9
        public static final int action_container = 0x7F060021;  // id:action_container
        public static final int action_divider = 0x7F060022;  // id:action_divider
        public static final int action_image = 0x7F060023;  // id:action_image
        public static final int action_text = 0x7F060024;  // id:action_text
        public static final int actions = 0x7F060025;  // id:actions
        public static final int async = 0x7F060029;  // id:async
        public static final int blocking = 0x7F06002B;  // id:blocking
        public static final int chronometer = 0x7F06002C;  // id:chronometer
        public static final int dialog_button = 0x7F06002F;  // id:dialog_button
        public static final int forever = 0x7F060039;  // id:forever
        public static final int icon = 0x7F06003C;  // id:icon
        public static final int icon_group = 0x7F06003D;  // id:icon_group
        public static final int info = 0x7F06003F;  // id:info
        public static final int italic = 0x7F060041;  // id:italic
        public static final int line1 = 0x7F060043;  // id:line1
        public static final int line3 = 0x7F060044;  // id:line3
        public static final int normal = 0x7F060046;  // id:normal
        public static final int notification_background = 0x7F060047;  // id:notification_background
        public static final int notification_main_column = 0x7F060048;  // id:notification_main_column
        public static final int notification_main_column_container = 0x7F060049;  // id:notification_main_column_container
        public static final int right_icon = 0x7F06004E;  // id:right_icon
        public static final int right_side = 0x7F06004F;  // id:right_side
        public static final int tag_accessibility_actions = 0x7F060051;  // id:tag_accessibility_actions
        public static final int tag_accessibility_clickable_spans = 0x7F060052;  // id:tag_accessibility_clickable_spans
        public static final int tag_accessibility_heading = 0x7F060053;  // id:tag_accessibility_heading
        public static final int tag_accessibility_pane_title = 0x7F060054;  // id:tag_accessibility_pane_title
        public static final int tag_screen_reader_focusable = 0x7F060058;  // id:tag_screen_reader_focusable
        public static final int tag_transition_group = 0x7F06005A;  // id:tag_transition_group
        public static final int tag_unhandled_key_event_manager = 0x7F06005B;  // id:tag_unhandled_key_event_manager
        public static final int tag_unhandled_key_listeners = 0x7F06005C;  // id:tag_unhandled_key_listeners
        public static final int text = 0x7F06005E;  // id:text
        public static final int text2 = 0x7F06005F;  // id:text2
        public static final int time = 0x7F060060;  // id:time
        public static final int title = 0x7F060061;  // id:title

    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 0x7F070001;  // integer:status_bar_notification_info_maxnum

    }

    public static final class layout {
        public static final int custom_dialog = 0x7F080001;  // layout:custom_dialog
        public static final int notification_action = 0x7F080004;  // layout:notification_action
        public static final int notification_action_tombstone = 0x7F080005;  // layout:notification_action_tombstone
        public static final int notification_template_custom_big = 0x7F080006;  // layout:notification_template_custom_big
        public static final int notification_template_icon_group = 0x7F080007;  // layout:notification_template_icon_group
        public static final int notification_template_part_chronometer = 0x7F080008;  // layout:notification_template_part_chronometer
        public static final int notification_template_part_time = 0x7F080009;  // layout:notification_template_part_time

    }

    public static final class string {
        public static final int status_bar_notification_info_overflow = 0x7F0B004F;  // string:status_bar_notification_info_overflow "999+"

    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 0x7F0C0004;  // style:TextAppearance.Compat.Notification
        public static final int TextAppearance_Compat_Notification_Info = 0x7F0C0005;  // style:TextAppearance.Compat.Notification.Info
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7F0C0006;  // style:TextAppearance.Compat.Notification.Line2
        public static final int TextAppearance_Compat_Notification_Time = 0x7F0C0007;  // style:TextAppearance.Compat.Notification.Time
        public static final int TextAppearance_Compat_Notification_Title = 0x7F0C0008;  // style:TextAppearance.Compat.Notification.Title
        public static final int Widget_Compat_NotificationActionContainer = 0x7F0C000D;  // style:Widget.Compat.NotificationActionContainer
        public static final int Widget_Compat_NotificationActionText = 0x7F0C000E;  // style:Widget.Compat.NotificationActionText

    }

    public static final class styleable {
        public static final int[] ColorStateListItem = null;
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] FontFamily = null;
        public static final int[] FontFamilyFont = null;
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int FontFamily_fontProviderSystemFontFamily = 6;
        public static final int[] GradientColor = null;
        public static final int[] GradientColorItem = null;
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;

        static {
            styleable.ColorStateListItem = new int[]{0x10101A5, 0x101031F, 0x7F010000};  // attr:alpha
            styleable.FontFamily = new int[]{0x7F010005, 0x7F010006, 0x7F010007, 0x7F010008, 0x7F010009, 0x7F01000A, 0x7F01000B};  // attr:fontProviderAuthority
            styleable.FontFamilyFont = new int[]{0x1010532, 0x1010533, 0x101053F, 0x101056F, 0x1010570, 0x7F010004, 0x7F01000C, 0x7F01000D, 0x7F01000E, 0x7F010012};  // attr:font
            styleable.GradientColor = new int[]{0x101019D, 0x101019E, 0x10101A1, 0x10101A2, 0x10101A3, 0x10101A4, 0x1010201, 0x101020B, 0x1010510, 0x1010511, 0x1010512, 0x1010513};
            styleable.GradientColorItem = new int[]{0x10101A5, 0x1010514};
        }
    }

}

