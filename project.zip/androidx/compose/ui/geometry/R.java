package androidx.compose.ui.geometry;

public final class R {
}

