package androidx.compose.ui.focus;

import androidx.compose.runtime.collection.MutableVector;
import androidx.compose.ui.ExperimentalComposeUiApi;
import androidx.compose.ui.node.ModifiedFocusNode;
import androidx.compose.ui.node.ModifiedFocusRequesterNode;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000B\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000 \r2\u00020\u0001:\u0001\rB\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010\b\u001A\u00020\tJ\u0006\u0010\n\u001A\u00020\tJ\u0006\u0010\u000B\u001A\u00020\fR\u001A\u0010\u0003\u001A\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0080\u0004¢\u0006\b\n\u0000\u001A\u0004\b\u0006\u0010\u0007¨\u0006\u000E"}, d2 = {"Landroidx/compose/ui/focus/FocusRequester;", "", "()V", "focusRequesterNodes", "Landroidx/compose/runtime/collection/MutableVector;", "Landroidx/compose/ui/node/ModifiedFocusRequesterNode;", "getFocusRequesterNodes$ui_release", "()Landroidx/compose/runtime/collection/MutableVector;", "captureFocus", "", "freeFocus", "requestFocus", "", "Companion", "ui_release"}, k = 1, mv = {1, 5, 1}, xi = 0x30)
public final class FocusRequester {
    @Metadata(d1 = {"\u0000\u001C\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001:\u0001\tB\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0007\u001A\u00020\bH\u0007R\u0011\u0010\u0003\u001A\u00020\u0004¢\u0006\b\n\u0000\u001A\u0004\b\u0005\u0010\u0006¨\u0006\n"}, d2 = {"Landroidx/compose/ui/focus/FocusRequester$Companion;", "", "()V", "Default", "Landroidx/compose/ui/focus/FocusRequester;", "getDefault", "()Landroidx/compose/ui/focus/FocusRequester;", "createRefs", "Landroidx/compose/ui/focus/FocusRequester$Companion$FocusRequesterFactory;", "FocusRequesterFactory", "ui_release"}, k = 1, mv = {1, 5, 1}, xi = 0x30)
    public static final class Companion {
        @ExperimentalComposeUiApi
        @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0010\bÇ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\t\u0010\u0003\u001A\u00020\u0004H\u0086\u0002J\t\u0010\u0005\u001A\u00020\u0004H\u0086\u0002J\t\u0010\u0006\u001A\u00020\u0004H\u0086\u0002J\t\u0010\u0007\u001A\u00020\u0004H\u0086\u0002J\t\u0010\b\u001A\u00020\u0004H\u0086\u0002J\t\u0010\t\u001A\u00020\u0004H\u0086\u0002J\t\u0010\n\u001A\u00020\u0004H\u0086\u0002J\t\u0010\u000B\u001A\u00020\u0004H\u0086\u0002J\t\u0010\f\u001A\u00020\u0004H\u0086\u0002J\t\u0010\r\u001A\u00020\u0004H\u0086\u0002J\t\u0010\u000E\u001A\u00020\u0004H\u0086\u0002J\t\u0010\u000F\u001A\u00020\u0004H\u0086\u0002J\t\u0010\u0010\u001A\u00020\u0004H\u0086\u0002J\t\u0010\u0011\u001A\u00020\u0004H\u0086\u0002J\t\u0010\u0012\u001A\u00020\u0004H\u0086\u0002J\t\u0010\u0013\u001A\u00020\u0004H\u0086\u0002¨\u0006\u0014"}, d2 = {"Landroidx/compose/ui/focus/FocusRequester$Companion$FocusRequesterFactory;", "", "()V", "component1", "Landroidx/compose/ui/focus/FocusRequester;", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "ui_release"}, k = 1, mv = {1, 5, 1}, xi = 0x30)
        public static final class FocusRequesterFactory {
            public static final int $stable;
            public static final FocusRequesterFactory INSTANCE;

            static {
                FocusRequesterFactory.INSTANCE = new FocusRequesterFactory();
            }

            public final FocusRequester component1() {
                return new FocusRequester();
            }

            public final FocusRequester component10() {
                return new FocusRequester();
            }

            public final FocusRequester component11() {
                return new FocusRequester();
            }

            public final FocusRequester component12() {
                return new FocusRequester();
            }

            public final FocusRequester component13() {
                return new FocusRequester();
            }

            public final FocusRequester component14() {
                return new FocusRequester();
            }

            public final FocusRequester component15() {
                return new FocusRequester();
            }

            public final FocusRequester component16() {
                return new FocusRequester();
            }

            public final FocusRequester component2() {
                return new FocusRequester();
            }

            public final FocusRequester component3() {
                return new FocusRequester();
            }

            public final FocusRequester component4() {
                return new FocusRequester();
            }

            public final FocusRequester component5() {
                return new FocusRequester();
            }

            public final FocusRequester component6() {
                return new FocusRequester();
            }

            public final FocusRequester component7() {
                return new FocusRequester();
            }

            public final FocusRequester component8() {
                return new FocusRequester();
            }

            public final FocusRequester component9() {
                return new FocusRequester();
            }
        }

        private Companion() {
        }

        public Companion(DefaultConstructorMarker defaultConstructorMarker0) {
        }

        @ExperimentalComposeUiApi
        public final FocusRequesterFactory createRefs() {
            return FocusRequesterFactory.INSTANCE;
        }

        public final FocusRequester getDefault() {
            return FocusRequester.Default;
        }
    }

    public static final int $stable;
    public static final Companion Companion;
    private static final FocusRequester Default;
    private final MutableVector focusRequesterNodes;

    static {
        FocusRequester.Companion = new Companion(null);
        FocusRequester.$stable = MutableVector.$stable;
        FocusRequester.Default = new FocusRequester();
    }

    public FocusRequester() {
        this.focusRequesterNodes = new MutableVector(new ModifiedFocusRequesterNode[16], 0);
    }

    public final boolean captureFocus() {
        if(!this.focusRequesterNodes.isNotEmpty()) {
            throw new IllegalStateException("\n   FocusRequester is not initialized. Here are some possible fixes:\n\n   1. Remember the FocusRequester: val focusRequester = remember { FocusRequester() }\n   2. Did you forget to add a Modifier.focusRequester() ?\n   3. Are you attempting to request focus during composition? Focus requests should be made in\n   response to some event. Eg Modifier.clickable { focusRequester.requestFocus() }\n");
        }
        MutableVector mutableVector0 = this.focusRequesterNodes;
        int v = mutableVector0.getSize();
        int v1 = 0;
        if(v > 0) {
            Object[] arr_object = mutableVector0.getContent();
            int v2 = 0;
            do {
                ModifiedFocusNode modifiedFocusNode0 = ((ModifiedFocusRequesterNode)arr_object[v1]).findFocusNode$ui_release();
                if(modifiedFocusNode0 != null && FocusTransactionsKt.captureFocus(modifiedFocusNode0)) {
                    v2 = 1;
                }
                ++v1;
            }
            while(v1 < v);
            v1 = v2;
        }
        return v1 != 0;
    }

    public final boolean freeFocus() {
        if(!this.focusRequesterNodes.isNotEmpty()) {
            throw new IllegalStateException("\n   FocusRequester is not initialized. Here are some possible fixes:\n\n   1. Remember the FocusRequester: val focusRequester = remember { FocusRequester() }\n   2. Did you forget to add a Modifier.focusRequester() ?\n   3. Are you attempting to request focus during composition? Focus requests should be made in\n   response to some event. Eg Modifier.clickable { focusRequester.requestFocus() }\n");
        }
        MutableVector mutableVector0 = this.focusRequesterNodes;
        int v = mutableVector0.getSize();
        int v1 = 0;
        if(v > 0) {
            Object[] arr_object = mutableVector0.getContent();
            int v2 = 0;
            do {
                ModifiedFocusNode modifiedFocusNode0 = ((ModifiedFocusRequesterNode)arr_object[v1]).findFocusNode$ui_release();
                if(modifiedFocusNode0 != null && FocusTransactionsKt.freeFocus(modifiedFocusNode0)) {
                    v2 = 1;
                }
                ++v1;
            }
            while(v1 < v);
            v1 = v2;
        }
        return v1 != 0;
    }

    public final MutableVector getFocusRequesterNodes$ui_release() {
        return this.focusRequesterNodes;
    }

    public final void requestFocus() {
        if(!this.focusRequesterNodes.isNotEmpty()) {
            throw new IllegalStateException("\n   FocusRequester is not initialized. Here are some possible fixes:\n\n   1. Remember the FocusRequester: val focusRequester = remember { FocusRequester() }\n   2. Did you forget to add a Modifier.focusRequester() ?\n   3. Are you attempting to request focus during composition? Focus requests should be made in\n   response to some event. Eg Modifier.clickable { focusRequester.requestFocus() }\n");
        }
        MutableVector mutableVector0 = this.focusRequesterNodes;
        int v = mutableVector0.getSize();
        if(v > 0) {
            Object[] arr_object = mutableVector0.getContent();
            int v1 = 0;
            while(true) {
                ModifiedFocusNode modifiedFocusNode0 = ((ModifiedFocusRequesterNode)arr_object[v1]).findFocusNode$ui_release();
                if(modifiedFocusNode0 != null) {
                    FocusTransactionsKt.requestFocus(modifiedFocusNode0, false);
                }
                ++v1;
                if(v1 >= v) {
                    break;
                }
            }
        }
    }
}

