package androidx.compose.runtime;

import kotlin.Metadata;
import kotlin.jvm.functions.Function2;

@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000B\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J\b\u0010\u0007\u001A\u00020\bH&J \u0010\t\u001A\u00020\b2\u0011\u0010\n\u001A\r\u0012\u0004\u0012\u00020\b0\u000B¢\u0006\u0002\b\fH&¢\u0006\u0002\u0010\rR\u0012\u0010\u0002\u001A\u00020\u0003X¦\u0004¢\u0006\u0006\u001A\u0004\b\u0004\u0010\u0005R\u0012\u0010\u0006\u001A\u00020\u0003X¦\u0004¢\u0006\u0006\u001A\u0004\b\u0006\u0010\u0005¨\u0006\u000E"}, d2 = {"Landroidx/compose/runtime/Composition;", "", "hasInvalidations", "", "getHasInvalidations", "()Z", "isDisposed", "dispose", "", "setContent", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(Lkotlin/jvm/functions/Function2;)V", "runtime_release"}, k = 1, mv = {1, 5, 1}, xi = 0x30)
public interface Composition {
    void dispose();

    boolean getHasInvalidations();

    boolean isDisposed();

    void setContent(Function2 arg1);
}

