package androidx.compose.runtime.external.kotlinx.collections.immutable.internal;

import kotlin.Metadata;

@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\bÀ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002¨\u0006\u0003"}, d2 = {"Landroidx/compose/runtime/external/kotlinx/collections/immutable/internal/EndOfChain;", "", "()V", "runtime_release"}, k = 1, mv = {1, 5, 1}, xi = 0x30)
public final class EndOfChain {
    public static final EndOfChain INSTANCE;

    static {
        EndOfChain.INSTANCE = new EndOfChain();
    }
}

