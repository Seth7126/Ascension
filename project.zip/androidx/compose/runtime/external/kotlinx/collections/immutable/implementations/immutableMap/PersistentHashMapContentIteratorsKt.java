package androidx.compose.runtime.external.kotlinx.collections.immutable.implementations.immutableMap;

import kotlin.Metadata;

@Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0010\b\n\u0000\"\u000E\u0010\u0000\u001A\u00020\u0001X\u0080T¢\u0006\u0002\n\u0000¨\u0006\u0002"}, d2 = {"TRIE_MAX_HEIGHT", "", "runtime_release"}, k = 2, mv = {1, 5, 1}, xi = 0x30)
public final class PersistentHashMapContentIteratorsKt {
    public static final int TRIE_MAX_HEIGHT = 7;

}

