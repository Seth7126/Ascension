package androidx.compose.runtime.external.kotlinx.collections.immutable.internal;

import kotlin.Metadata;

@Metadata(d1 = {"\u0000\u000E\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000B\n\u0000\u001A\u0010\u0010\u0000\u001A\u00020\u00012\u0006\u0010\u0002\u001A\u00020\u0003H\u0000¨\u0006\u0004"}, d2 = {"assert", "", "condition", "", "runtime_release"}, k = 2, mv = {1, 5, 1}, xi = 0x30)
public final class CommonFunctionsKt {
    public static final void assert(boolean z) {
    }
}

