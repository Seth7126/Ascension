package androidx.compose.runtime;

import android.os.Looper;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\u0000\u0006\n\u0002\u0018\u0002\n\u0000\u0010\u0001\u001A\u00020\u0000H\n"}, d2 = {"Landroidx/compose/runtime/MonotonicFrameClock;", "<anonymous>"}, k = 3, mv = {1, 5, 1})
final class ActualAndroid_androidKt.DefaultMonotonicFrameClock.2 extends Lambda implements Function0 {
    public static final ActualAndroid_androidKt.DefaultMonotonicFrameClock.2 INSTANCE;

    static {
        ActualAndroid_androidKt.DefaultMonotonicFrameClock.2.INSTANCE = new ActualAndroid_androidKt.DefaultMonotonicFrameClock.2();
    }

    ActualAndroid_androidKt.DefaultMonotonicFrameClock.2() {
        super(0);
    }

    public final MonotonicFrameClock invoke() {
        return Looper.getMainLooper() != null ? DefaultChoreographerFrameClock.INSTANCE : SdkStubsFallbackFrameClock.INSTANCE;
    }

    @Override  // kotlin.jvm.functions.Function0
    public Object invoke() {
        return this.invoke();
    }
}

