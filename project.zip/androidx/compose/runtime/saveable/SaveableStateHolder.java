package androidx.compose.runtime.saveable;

import androidx.compose.runtime.Composer;
import kotlin.Metadata;
import kotlin.jvm.functions.Function2;

@Metadata(d1 = {"\u0000\u001E\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J(\u0010\u0002\u001A\u00020\u00032\u0006\u0010\u0004\u001A\u00020\u00012\u0011\u0010\u0005\u001A\r\u0012\u0004\u0012\u00020\u00030\u0006¢\u0006\u0002\b\u0007H\'¢\u0006\u0002\u0010\bJ\u0010\u0010\t\u001A\u00020\u00032\u0006\u0010\u0004\u001A\u00020\u0001H&¨\u0006\n"}, d2 = {"Landroidx/compose/runtime/saveable/SaveableStateHolder;", "", "SaveableStateProvider", "", "key", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V", "removeState", "runtime-saveable_release"}, k = 1, mv = {1, 5, 1}, xi = 0x30)
public interface SaveableStateHolder {
    void SaveableStateProvider(Object arg1, Function2 arg2, Composer arg3, int arg4);

    void removeState(Object arg1);
}

