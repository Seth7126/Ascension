package androidx.activity.compose;

import androidx.activity.OnBackPressedDispatcherOwner;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\u0000\u0006\n\u0002\u0018\u0002\n\u0000\u0010\u0001\u001A\u0004\u0018\u00010\u0000H\n"}, d2 = {"Landroidx/activity/OnBackPressedDispatcherOwner;", "<anonymous>"}, k = 3, mv = {1, 5, 1})
final class LocalOnBackPressedDispatcherOwner.LocalOnBackPressedDispatcherOwner.1 extends Lambda implements Function0 {
    public static final LocalOnBackPressedDispatcherOwner.LocalOnBackPressedDispatcherOwner.1 INSTANCE;

    static {
        LocalOnBackPressedDispatcherOwner.LocalOnBackPressedDispatcherOwner.1.INSTANCE = new LocalOnBackPressedDispatcherOwner.LocalOnBackPressedDispatcherOwner.1();
    }

    LocalOnBackPressedDispatcherOwner.LocalOnBackPressedDispatcherOwner.1() {
        super(0);
    }

    public final OnBackPressedDispatcherOwner invoke() [...] // Inlined contents

    @Override  // kotlin.jvm.functions.Function0
    public Object invoke() {
        return null;
    }
}

